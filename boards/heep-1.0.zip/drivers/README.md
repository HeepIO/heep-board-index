Note the old driver files that used to be in this folder have been moved to this new location:

    https://github.com/adafruit/Adafruit_Windows_Drivers/tree/master/Drivers
